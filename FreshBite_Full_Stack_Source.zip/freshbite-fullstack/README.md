# FreshBite Foods — Full-stack starter

This is a single downloadable ZIP containing the FreshBite website source and a Node/Express/MongoDB API. It is **not live-hosted** and cannot accept real orders until you configure the external services and deploy it.

## Included
- Express API with MongoDB models for users, products, orders and coupons
- Password hashing with bcrypt, HttpOnly JWT cookie, role-based admin routes
- Product search/filter API, registration/login/profile, addresses, order history
- Server-side stock checks and order total calculation
- Razorpay order creation and payment signature verification (test/live keys configured only on server)
- Seed script for sample food products
- The current single-file storefront in `client/index.html`

## Requirements
- Node.js 20+
- MongoDB Atlas or local MongoDB
- Razorpay account for online payments (test mode first)
- Optional Cloudinary account for image uploads (image URLs work without it)

## Run locally
1. Extract this ZIP anywhere.
2. Open a terminal in `freshbite-fullstack/server`.
3. Run `npm install`.
4. Copy `.env.example` to `.env` and set `MONGODB_URI`, `JWT_SECRET`, `CLIENT_ORIGIN`, and `ADMIN_EMAIL`.
5. Run `npm run seed` to add sample products.
6. Run `npm run dev`.
7. Open `http://localhost:4000/api/health` to check the API.

The website file is `client/index.html`. The API runs separately at `http://localhost:4000`. To run as a connected production shop, the storefront's checkout/auth/cart calls must be wired to these API endpoints and deployed under the configured origin; the supplied HTML remains the presentation/demo storefront, so do not accept real orders from it yet.

## Create the first admin
1. Register a customer account through `POST /api/auth/register`.
2. In MongoDB, change that user's `role` from `customer` to `admin` using MongoDB Atlas UI or Compass.
3. Sign in again. Admin endpoints then require the signed-in admin cookie.

For production, do not expose the admin role change in a public endpoint. Use a controlled database operation or a one-time protected bootstrap process.

## Environment variables
See `.env.example`. Never commit `.env`, API secrets, database credentials, or Razorpay secret keys.

## API routes
- `GET /api/health`
- `GET /api/products`, `GET /api/products/:id`
- `POST /api/auth/register`, `POST /api/auth/login`, `POST /api/auth/logout`, `GET /api/auth/me`
- `PUT /api/auth/profile`, `POST /api/auth/addresses`
- `POST /api/orders`, `GET /api/orders/my`, `GET /api/orders/:id`
- `POST /api/payments/razorpay/order`, `POST /api/payments/razorpay/verify`
- Admin: `GET /api/admin/stats`, `GET /api/admin/orders`, `PATCH /api/admin/orders/:id/status`, `POST /api/admin/products`, `PATCH /api/admin/products/:id`, `DELETE /api/admin/products/:id`, `POST /api/admin/coupons`

## Important launch checklist
- Connect and test the React/HTML storefront to the API (the supplied single-file page is still a demo frontend).
- Set real domain, HTTPS, production MongoDB, CORS origin and strong secrets.
- Add email/SMS provider for password reset and notifications.
- Add Cloudinary or another trusted image uploader if administrators must upload images.
- Configure Razorpay webhook and reconcile payment status server-side before fulfilling paid orders.
- Add terms, privacy, cancellation/refund policy, GST/business details, shipping rates, backups, monitoring and security review.
- Use Razorpay test credentials until all payment tests pass. Do not enter real card details in this project.
