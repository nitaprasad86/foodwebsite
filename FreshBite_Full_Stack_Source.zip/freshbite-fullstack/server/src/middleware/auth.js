import jwt from "jsonwebtoken";
import User from "../models/User.js";
export async function requireAuth(req,res,next){
  try {
    const token=req.cookies?.fb_session;
    if(!token) return res.status(401).json({error:"Please sign in first."});
    const payload=jwt.verify(token,process.env.JWT_SECRET);
    const user=await User.findById(payload.sub);
    if(!user || !user.active) return res.status(401).json({error:"Session is no longer valid."});
    req.user=user; next();
  } catch { return res.status(401).json({error:"Your session expired. Please sign in again."}); }
}
export function requireAdmin(req,res,next){
  if(req.user?.role!=="admin") return res.status(403).json({error:"Administrator access required."});
  next();
}
