import mongoose from "mongoose";
const schema = new mongoose.Schema({
  name:{type:String,required:true,trim:true,maxlength:140,index:"text"},
  slug:{type:String,required:true,unique:true},
  description:{type:String,default:"",maxlength:1500},
  category:{type:String,required:true,enum:["Snacks and Namkeen","Bakery Products","Sweets and Chocolates","Spices and Masalas","Packaged Foods","Dry Fruits and Nuts","Beverages","Healthy and Organic Foods"]},
  pricePaise:{type:Number,required:true,min:0},
  mrpPaise:{type:Number,required:true,min:0},
  weight:{type:String,required:true,maxlength:40},
  imageUrl:{type:String,default:"",maxlength:1000},
  stock:{type:Number,default:0,min:0,validate:Number.isInteger},
  rating:{type:Number,default:4.5,min:0,max:5},
  featured:{type:Boolean,default:false},
  active:{type:Boolean,default:true}
},{timestamps:true});
schema.index({name:"text",description:"text",category:"text"});
export default mongoose.model("Product",schema);
