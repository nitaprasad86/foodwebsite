import mongoose from "mongoose";
const schema = new mongoose.Schema({
  code:{type:String,required:true,unique:true,uppercase:true,trim:true},
  percent:{type:Number,required:true,min:1,max:80},
  minSubtotalPaise:{type:Number,default:0,min:0},
  active:{type:Boolean,default:true},
  expiresAt:Date,
  maxUses:{type:Number,default:1000,min:1},
  uses:{type:Number,default:0,min:0}
},{timestamps:true});
export default mongoose.model("Coupon",schema);
