import mongoose from "mongoose";
const addressSchema = new mongoose.Schema({
  label: {type:String, default:"Home", maxlength:40},
  recipient: {type:String, required:true, maxlength:100},
  phone: {type:String, required:true, match:/^[6-9]\d{9}$/},
  line1: {type:String, required:true, maxlength:250},
  city: {type:String, required:true, maxlength:80},
  state: {type:String, required:true, maxlength:80},
  pin: {type:String, required:true, match:/^\d{6}$/},
  isDefault: {type:Boolean, default:false}
}, {_id:true});
const userSchema = new mongoose.Schema({
  name:{type:String,required:true,trim:true,maxlength:100},
  email:{type:String,required:true,unique:true,lowercase:true,trim:true,index:true},
  phone:{type:String,match:/^[6-9]\d{9}$/},
  passwordHash:{type:String,required:true,select:false},
  role:{type:String,enum:["customer","admin"],default:"customer"},
  addresses:[addressSchema],
  active:{type:Boolean,default:true}
},{timestamps:true});
export default mongoose.model("User",userSchema);
