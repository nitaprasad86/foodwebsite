import mongoose from "mongoose";
const itemSchema = new mongoose.Schema({
  product:{type:mongoose.Schema.Types.ObjectId,ref:"Product",required:true},
  name:{type:String,required:true},
  imageUrl:String,
  unitPricePaise:{type:Number,required:true,min:0},
  quantity:{type:Number,required:true,min:1,max:50}
},{_id:false});
const schema = new mongoose.Schema({
  orderNumber:{type:String,unique:true,index:true},
  user:{type:mongoose.Schema.Types.ObjectId,ref:"User",required:true,index:true},
  items:{type:[itemSchema],required:true},
  subtotalPaise:{type:Number,required:true},
  discountPaise:{type:Number,default:0},
  deliveryPaise:{type:Number,default:0},
  totalPaise:{type:Number,required:true},
  couponCode:{type:String,default:""},
  address:{recipient:String,phone:String,line1:String,city:String,state:String,pin:String},
  paymentMethod:{type:String,enum:["cod","razorpay"],required:true},
  paymentStatus:{type:String,enum:["pending","paid","failed","refunded"],default:"pending"},
  razorpayOrderId:String,
  razorpayPaymentId:String,
  status:{type:String,enum:["placed","confirmed","packed","shipped","delivered","cancelled"],default:"placed"},
  notes:{type:String,maxlength:500}
},{timestamps:true});
export default mongoose.model("Order",schema);
