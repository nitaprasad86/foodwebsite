import {Router} from "express";
import {z} from "zod";
import Order from "../models/Order.js";
import Product from "../models/Product.js";
import Coupon from "../models/Coupon.js";
import {requireAuth} from "../middleware/auth.js";
const router=Router();router.use(requireAuth);
const addressSchema=z.object({recipient:z.string().min(2).max(100),phone:z.string().regex(/^[6-9]\d{9}$/),line1:z.string().min(5).max(250),city:z.string().min(2).max(80),state:z.string().min(2).max(80),pin:z.string().regex(/^\d{6}$/)});
router.post("/",async(req,res,next)=>{
 const session=await Product.startSession();
 try{
  const data=z.object({items:z.array(z.object({productId:z.string().min(1),quantity:z.number().int().min(1).max(50)})).min(1).max(50),address:addressSchema,paymentMethod:z.enum(["cod","razorpay"]),couponCode:z.string().max(40).optional()}).parse(req.body);
  const response=await session.withTransaction(async()=>{
   const ids=[...new Set(data.items.map(i=>i.productId))];
   const products=await Product.find({_id:{$in:ids},active:true}).session(session);
   if(products.length!==ids.length)throw Object.assign(new Error("One or more products are unavailable."),{status:400});
   const map=new Map(products.map(p=>[p._id.toString(),p]));
   let subtotal=0;const lineItems=[];
   for(const i of data.items){const p=map.get(i.productId);if(p.stock<i.quantity)throw Object.assign(new Error(`${p.name} has only ${p.stock} left in stock.`),{status:409});subtotal+=p.pricePaise*i.quantity;lineItems.push({product:p._id,name:p.name,imageUrl:p.imageUrl,unitPricePaise:p.pricePaise,quantity:i.quantity})}
   let discount=0,coupon=null;
   if(data.couponCode){coupon=await Coupon.findOne({code:data.couponCode.toUpperCase(),active:true}).session(session);if(!coupon||coupon.uses>=coupon.maxUses||(coupon.expiresAt&&coupon.expiresAt<new Date())||subtotal<coupon.minSubtotalPaise)throw Object.assign(new Error("Coupon is invalid or not eligible."),{status:400});discount=Math.floor(subtotal*coupon.percent/100)}
   const delivery=subtotal-discount>=79900?0:4900,total=subtotal-discount+delivery;
   for(const i of data.items){const p=map.get(i.productId);p.stock-=i.quantity;await p.save({session})}
   if(coupon){coupon.uses+=1;await coupon.save({session})}
   const orderNumber="FB"+Date.now().toString().slice(-8)+Math.floor(Math.random()*90+10);
   const [order]=await Order.create([{orderNumber,user:req.user._id,items:lineItems,subtotalPaise:subtotal,discountPaise:discount,deliveryPaise:delivery,totalPaise:total,couponCode:coupon?.code||"",address:data.address,paymentMethod:data.paymentMethod,paymentStatus:"pending"}],{session});
   return {order};
  });
  res.status(201).json({order:response.order});
 }catch(e){next(e)}finally{await session.endSession()}
});
router.get("/my",async(req,res,next)=>{try{const orders=await Order.find({user:req.user._id}).sort({createdAt:-1}).limit(100);res.json({orders})}catch(e){next(e)}});
router.get("/:id",async(req,res,next)=>{try{const order=await Order.findOne({_id:req.params.id,user:req.user._id});if(!order)return res.status(404).json({error:"Order not found."});res.json({order})}catch(e){next(e)}});
export default router;
