import {Router} from "express";
import crypto from "node:crypto";
import Razorpay from "razorpay";
import {z} from "zod";
import {requireAuth} from "../middleware/auth.js";
import Order from "../models/Order.js";
const router=Router();
function razorpayClient(){
 if(!process.env.RAZORPAY_KEY_ID||!process.env.RAZORPAY_KEY_SECRET)throw Object.assign(new Error("Razorpay is not configured. Add test keys to the server environment."),{status:503});
 return new Razorpay({key_id:process.env.RAZORPAY_KEY_ID,key_secret:process.env.RAZORPAY_KEY_SECRET});
}
router.post("/razorpay/order",requireAuth,async(req,res,next)=>{
 try{
  const {orderId}=z.object({orderId:z.string().min(1)}).parse(req.body);
  const order=await Order.findOne({_id:orderId,user:req.user._id,paymentMethod:"razorpay",paymentStatus:"pending"});
  if(!order)return res.status(404).json({error:"Pending online-payment order not found."});
  const rp=razorpayClient();
  const rpOrder=await rp.orders.create({amount:order.totalPaise,currency:"INR",receipt:order.orderNumber,notes:{internalOrderId:order._id.toString()}});
  order.razorpayOrderId=rpOrder.id;await order.save();
  res.json({keyId:process.env.RAZORPAY_KEY_ID,razorpayOrderId:rpOrder.id,amount:rpOrder.amount,currency:rpOrder.currency,orderId:order._id});
 }catch(e){next(e)}
});
router.post("/razorpay/verify",requireAuth,async(req,res,next)=>{
 try{
  const d=z.object({orderId:z.string().min(1),razorpay_order_id:z.string().min(1),razorpay_payment_id:z.string().min(1),razorpay_signature:z.string().min(1)}).parse(req.body);
  const order=await Order.findOne({_id:d.orderId,user:req.user._id,paymentMethod:"razorpay"});
  if(!order||order.razorpayOrderId!==d.razorpay_order_id)return res.status(400).json({error:"Payment order mismatch."});
  const expected=crypto.createHmac("sha256",process.env.RAZORPAY_KEY_SECRET||"").update(`${d.razorpay_order_id}|${d.razorpay_payment_id}`).digest("hex");
  const a=Buffer.from(expected),b=Buffer.from(d.razorpay_signature);
  if(a.length!==b.length||!crypto.timingSafeEqual(a,b))return res.status(400).json({error:"Payment signature verification failed."});
  order.razorpayPaymentId=d.razorpay_payment_id;order.paymentStatus="paid";order.status="confirmed";await order.save();
  res.json({verified:true,order});
 }catch(e){next(e)}
});
export default router;
