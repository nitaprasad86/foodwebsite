import {Router} from "express";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import {z} from "zod";
import User from "../models/User.js";
import {requireAuth} from "../middleware/auth.js";
const router=Router();
const cookieOptions=()=>({httpOnly:true,secure:process.env.NODE_ENV==="production",sameSite:"lax",path:"/",maxAge:7*24*60*60*1000});
const issue=(user,res)=>{
  const token=jwt.sign({sub:user._id.toString()},process.env.JWT_SECRET,{expiresIn:process.env.JWT_EXPIRES_IN||"7d"});
  res.cookie("fb_session",token,cookieOptions());
};
const publicUser=u=>({id:u._id,name:u.name,email:u.email,phone:u.phone,role:u.role,addresses:u.addresses});
const credentials=z.object({email:z.string().email().max(254),password:z.string().min(8).max(128)});
router.post("/register",async(req,res,next)=>{
 try{
  const data=z.object({name:z.string().trim().min(2).max(100),email:z.string().email().max(254),password:z.string().min(8).max(128),phone:z.string().regex(/^[6-9]\d{9}$/).optional()}).parse(req.body);
  const email=data.email.toLowerCase();
  if(await User.exists({email})) return res.status(409).json({error:"An account with this email already exists."});
  const passwordHash=await bcrypt.hash(data.password,12);
  const user=await User.create({name:data.name,email,passwordHash,phone:data.phone});
  issue(user,res);res.status(201).json({user:publicUser(user)});
 }catch(e){next(e)}
});
router.post("/login",async(req,res,next)=>{
 try{
  const data=credentials.parse(req.body);const user=await User.findOne({email:data.email.toLowerCase()}).select("+passwordHash");
  if(!user||!user.active||!(await bcrypt.compare(data.password,user.passwordHash))) return res.status(401).json({error:"Email or password is incorrect."});
  issue(user,res);res.json({user:publicUser(user)});
 }catch(e){next(e)}
});
router.post("/logout",(req,res)=>{res.clearCookie("fb_session",{httpOnly:true,secure:process.env.NODE_ENV==="production",sameSite:"lax",path:"/"});res.json({ok:true})});
router.get("/me",requireAuth,(req,res)=>res.json({user:publicUser(req.user)}));
router.put("/profile",requireAuth,async(req,res,next)=>{
 try{const data=z.object({name:z.string().trim().min(2).max(100),phone:z.string().regex(/^[6-9]\d{9}$/).optional()}).parse(req.body);
 req.user.name=data.name;if(data.phone)req.user.phone=data.phone;await req.user.save();res.json({user:publicUser(req.user)});
 }catch(e){next(e)}
});
router.post("/addresses",requireAuth,async(req,res,next)=>{
 try{
  const a=z.object({label:z.string().max(40).optional(),recipient:z.string().min(2).max(100),phone:z.string().regex(/^[6-9]\d{9}$/),line1:z.string().min(5).max(250),city:z.string().min(2).max(80),state:z.string().min(2).max(80),pin:z.string().regex(/^\d{6}$/),isDefault:z.boolean().optional()}).parse(req.body);
  if(a.isDefault)req.user.addresses.forEach(x=>x.isDefault=false);
  req.user.addresses.push(a);await req.user.save();res.status(201).json({addresses:req.user.addresses});
 }catch(e){next(e)}
});
export default router;
