import {Router} from "express";
import Product from "../models/Product.js";
const router=Router();
router.get("/",async(req,res,next)=>{
 try{
  const {q,category,sort="featured",page="1",limit="12",minPrice,maxPrice}=req.query;
  const filter={active:true};
  if(category)filter.category=category;
  if(q)filter.$text={$search:String(q).slice(0,100)};
  if(minPrice||maxPrice){filter.pricePaise={};if(minPrice)filter.pricePaise.$gte=Math.max(0,Number(minPrice)*100);if(maxPrice)filter.pricePaise.$lte=Math.max(0,Number(maxPrice)*100)}
  const sortMap={featured:{featured:-1,createdAt:-1},low:{pricePaise:1},high:{pricePaise:-1},rating:{rating:-1}};
  const p=Math.max(1,parseInt(page)||1),l=Math.min(48,Math.max(1,parseInt(limit)||12));
  const [items,total]=await Promise.all([Product.find(filter).sort(sortMap[sort]||sortMap.featured).skip((p-1)*l).limit(l),Product.countDocuments(filter)]);
  res.json({items,total,page:p,pages:Math.ceil(total/l)});
 }catch(e){next(e)}
});
router.get("/:id",async(req,res,next)=>{try{const p=await Product.findOne({_id:req.params.id,active:true});if(!p)return res.status(404).json({error:"Product not found."});res.json({product:p})}catch(e){next(e)}});
export default router;
