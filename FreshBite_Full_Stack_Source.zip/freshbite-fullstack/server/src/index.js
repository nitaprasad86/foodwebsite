import "dotenv/config";
import express from "express";
import mongoose from "mongoose";
import cookieParser from "cookie-parser";
import cors from "cors";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import authRoutes from "./routes/auth.js";
import productRoutes from "./routes/products.js";
import orderRoutes from "./routes/orders.js";
import paymentRoutes from "./routes/payments.js";
import adminRoutes from "./routes/admin.js";
const app=express();
if(!process.env.JWT_SECRET||process.env.JWT_SECRET.length<32){console.error("JWT_SECRET must be at least 32 characters.");process.exit(1)}
app.disable("x-powered-by");app.use(helmet());
app.use(cors({origin:process.env.CLIENT_ORIGIN?.split(",")||"http://localhost:5173",credentials:true}));
app.use(express.json({limit:"200kb"}));app.use(cookieParser());
app.use("/api/auth",rateLimit({windowMs:15*60*1000,limit:30,standardHeaders:true,legacyHeaders:false}));
app.get("/api/health",(req,res)=>res.json({ok:true,service:"FreshBite Foods API"}));
app.use("/api/auth",authRoutes);
app.use("/api/products",productRoutes);
app.use("/api/orders",orderRoutes);
app.use("/api/payments",paymentRoutes);
app.use("/api/admin",adminRoutes);
app.use((req,res)=>res.status(404).json({error:"Route not found."}));
app.use((err,req,res,next)=>{
 if(err?.name==="ZodError")return res.status(400).json({error:"Please check the submitted fields.",details:err.issues.map(i=>({field:i.path.join("."),message:i.message}))});
 if(err?.code===11000)return res.status(409).json({error:"A record with this value already exists."});
 const status=err.status||500;
 if(status===500)console.error(err);
 res.status(status).json({error:status===500?"Unexpected server error. Please try again.":err.message});
});
const port=Number(process.env.PORT)||4000;
try{await mongoose.connect(process.env.MONGODB_URI||"mongodb://127.0.0.1:27017/freshbite");app.listen(port,()=>console.log(`FreshBite API listening on http://localhost:${port}`))}
catch(e){console.error("Database connection failed:",e.message);process.exit(1)}
