import "dotenv/config";
import mongoose from "mongoose";
import Product from "../src/models/Product.js";
import Coupon from "../src/models/Coupon.js";
const rows=[
["Classic Masala Namkeen","classic-masala-namkeen","Snacks and Namkeen",9900,12000,"200 g",25,"https://images.unsplash.com/photo-1621939514649-280e2aa7a2f9?auto=format&fit=crop&w=700&q=80"],
["Butter Cookies","butter-cookies","Bakery Products",14900,18000,"250 g",18,"https://images.unsplash.com/photo-1499636136210-6f4ee915583e?auto=format&fit=crop&w=700&q=80"],
["Kaju Katli","kaju-katli","Sweets and Chocolates",34900,39900,"250 g",12,"https://images.unsplash.com/photo-1605197161470-5d6e7f6a7d20?auto=format&fit=crop&w=700&q=80"],
["Garam Masala","garam-masala","Spices and Masalas",8900,11000,"100 g",40,"https://images.unsplash.com/photo-1596040033229-a9821ebd058d?auto=format&fit=crop&w=700&q=80"],
["Premium Basmati Rice","premium-basmati-rice","Packaged Foods",27900,32000,"1 kg",30,"https://images.unsplash.com/photo-1586201375761-83865001e31c?auto=format&fit=crop&w=700&q=80"],
["California Almonds","california-almonds","Dry Fruits and Nuts",39900,45000,"500 g",14,"https://images.unsplash.com/photo-1508061253366-f7da158b6d46?auto=format&fit=crop&w=700&q=80"],
["Mango Fruit Drink","mango-fruit-drink","Beverages",4000,5000,"200 ml",50,"https://images.unsplash.com/photo-1546173159-315724a31696?auto=format&fit=crop&w=700&q=80"],
["Organic Rolled Oats","organic-rolled-oats","Healthy and Organic Foods",17900,21000,"500 g",22,"https://images.unsplash.com/photo-1517673132405-a56a62b18caf?auto=format&fit=crop&w=700&q=80"]
];
try{
 await mongoose.connect(process.env.MONGODB_URI||"mongodb://127.0.0.1:27017/freshbite");
 for(const r of rows){await Product.updateOne({slug:r[1]},{$setOnInsert:{name:r[0],slug:r[1],category:r[2],pricePaise:r[3],mrpPaise:r[4],weight:r[5],stock:r[6],imageUrl:r[7],description:`Quality ${r[0].toLowerCase()} for your pantry.`,rating:4.7,featured:true,active:true}},{upsert:true})}
 await Coupon.updateOne({code:"FRESH10"},{$setOnInsert:{code:"FRESH10",percent:10,minSubtotalPaise:29900,maxUses:1000,active:true}},{upsert:true});
 console.log("Sample products and FRESH10 coupon seeded.");await mongoose.disconnect();
}catch(e){console.error(e);process.exit(1)}
